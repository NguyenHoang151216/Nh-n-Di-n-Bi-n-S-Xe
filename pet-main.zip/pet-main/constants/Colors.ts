export default {
    PRIMARY: '#E8B20E',
    GRAY: '#8F8e8d',
    WHITE: '#FFFFFF',
}